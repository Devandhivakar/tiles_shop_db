import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Main {

    private static final Dimension BUTTON_SIZE = new Dimension(200, 35);
    private static final Dimension FIELD_SIZE = new Dimension(200, 25);

    private static Connection connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/tile_company_db", "root", "root");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Database connection failed: " + e.getMessage());
            return null;
        }
    }

    private static void addLabelAndField(String labelText, JTextField field, JPanel panel, GridBagConstraints gbc, Font font, int row) {
        gbc.gridx = 0;
        gbc.gridy = row;
        JLabel label = new JLabel(labelText);
        label.setFont(font);
        panel.add(label, gbc);

        gbc.gridx = 1;
        panel.add(field, gbc);
    }

    private static void restrictToNumeric(JTextField field) {
        field.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume();
                }
            }
        });
    }

    private static JPanel createTilesPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(255, 223, 186));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        Font labelFont = new Font("SansSerif", Font.PLAIN, 12);

        JTextField nameField = new JTextField(); nameField.setPreferredSize(FIELD_SIZE);
        JTextField categoryField = new JTextField(); categoryField.setPreferredSize(FIELD_SIZE);
        JTextField sizeField = new JTextField(); sizeField.setPreferredSize(FIELD_SIZE);
        JTextField colorField = new JTextField(); colorField.setPreferredSize(FIELD_SIZE);
        JTextField priceField = new JTextField(); priceField.setPreferredSize(FIELD_SIZE);
        JTextField stockField = new JTextField(); stockField.setPreferredSize(FIELD_SIZE);
        JTextField descriptionField = new JTextField(); descriptionField.setPreferredSize(FIELD_SIZE);

        restrictToNumeric(priceField);
        restrictToNumeric(stockField);

        int y = 0;
        addLabelAndField("Tile Name:", nameField, panel, gbc, labelFont, y++);
        addLabelAndField("Category:", categoryField, panel, gbc, labelFont, y++);
        addLabelAndField("Size:", sizeField, panel, gbc, labelFont, y++);
        addLabelAndField("Color:", colorField, panel, gbc, labelFont, y++);
        addLabelAndField("Price:", priceField, panel, gbc, labelFont, y++);
        addLabelAndField("Stock Quantity:", stockField, panel, gbc, labelFont, y++);
        addLabelAndField("Description:", descriptionField, panel, gbc, labelFont, y++);

        gbc.gridx = 0;
        gbc.gridy = y;
        gbc.gridwidth = 2;
        JButton submitButton = new JButton("Add Tile");
        submitButton.setBackground(new Color(255, 223, 0));
        submitButton.setPreferredSize(BUTTON_SIZE);
        panel.add(submitButton, gbc);

        submitButton.addActionListener(e -> {
            Connection con = connect();
            if (con == null) return;
            String sql = "INSERT INTO tiles (name, category, size, color, price, stock_quantity, description) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = con.prepareStatement(sql)) {
                stmt.setString(1, nameField.getText());
                stmt.setString(2, categoryField.getText());
                stmt.setString(3, sizeField.getText());
                stmt.setString(4, colorField.getText());
                stmt.setDouble(5, Double.parseDouble(priceField.getText()));
                stmt.setInt(6, Integer.parseInt(stockField.getText()));
                stmt.setString(7, descriptionField.getText());
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(panel, "Tile inserted successfully!");
                nameField.setText(""); categoryField.setText(""); sizeField.setText(""); colorField.setText("");
                priceField.setText(""); stockField.setText(""); descriptionField.setText("");
            } catch (SQLException | NumberFormatException ex) {
                JOptionPane.showMessageDialog(panel, "Error: " + ex.getMessage());
            }
        });
        return panel;
    }

    private static JPanel createCustomersPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(255, 250, 240));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        Font labelFont = new Font("SansSerif", Font.PLAIN, 12);

        JTextField customerNameField = new JTextField(); customerNameField.setPreferredSize(FIELD_SIZE);
        JTextField emailField = new JTextField(); emailField.setPreferredSize(FIELD_SIZE);
        JTextField phoneField = new JTextField(); phoneField.setPreferredSize(FIELD_SIZE);
        JTextField addressField = new JTextField(); addressField.setPreferredSize(FIELD_SIZE);

        restrictToNumeric(phoneField);

        int y = 0;
        addLabelAndField("Customer Name:", customerNameField, panel, gbc, labelFont, y++);
        addLabelAndField("Email:", emailField, panel, gbc, labelFont, y++);
        addLabelAndField("Phone:", phoneField, panel, gbc, labelFont, y++);
        addLabelAndField("Address:", addressField, panel, gbc, labelFont, y++);

        gbc.gridx = 0;
        gbc.gridy = y;
        gbc.gridwidth = 2;
        JButton submitButton = new JButton("Add Customer");
        submitButton.setBackground(new Color(255, 223, 0));
        submitButton.setPreferredSize(BUTTON_SIZE);
        panel.add(submitButton, gbc);

        submitButton.addActionListener(e -> {
            Connection con = connect();
            if (con == null) return;
            String sql = "INSERT INTO customers (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = con.prepareStatement(sql)) {
                stmt.setString(1, customerNameField.getText());
                stmt.setString(2, emailField.getText());
                stmt.setString(3, phoneField.getText());
                stmt.setString(4, addressField.getText());
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(panel, "Customer inserted successfully!");
                customerNameField.setText(""); emailField.setText(""); phoneField.setText(""); addressField.setText("");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(panel, "SQL Error: " + ex.getMessage());
            }
        });
        return panel;
    }

    private static JPanel createSuppliersPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(240, 255, 255));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        Font labelFont = new Font("SansSerif", Font.PLAIN, 12);

        JTextField supplierNameField = new JTextField(); supplierNameField.setPreferredSize(FIELD_SIZE);
        JTextField contactField = new JTextField(); contactField.setPreferredSize(FIELD_SIZE);
        JTextField addressField = new JTextField(); addressField.setPreferredSize(FIELD_SIZE);

        restrictToNumeric(contactField);

        int y = 0;
        addLabelAndField("Supplier Name:", supplierNameField, panel, gbc, labelFont, y++);
        addLabelAndField("Contact Info:", contactField, panel, gbc, labelFont, y++);
        addLabelAndField("Address:", addressField, panel, gbc, labelFont, y++);

        gbc.gridx = 0; gbc.gridy = y; gbc.gridwidth = 2;
        JButton submitButton = new JButton("Add Supplier");
        submitButton.setBackground(new Color(255, 223, 0));
        submitButton.setPreferredSize(BUTTON_SIZE);
        panel.add(submitButton, gbc);

        submitButton.addActionListener(e -> {
            Connection con = connect();
            if (con == null) return;
            String sql = "INSERT INTO suppliers (name, contact_info, address) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = con.prepareStatement(sql)) {
                stmt.setString(1, supplierNameField.getText());
                stmt.setString(2, contactField.getText());
                stmt.setString(3, addressField.getText());
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(panel, "Supplier inserted successfully!");
                supplierNameField.setText(""); contactField.setText(""); addressField.setText("");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(panel, "SQL Error: " + ex.getMessage());
            }
        });
        return panel;
    }

    private static JPanel createPaymentsPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(245, 245, 220));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        Font labelFont = new Font("SansSerif", Font.PLAIN, 12);

        JTextField customerIdField = new JTextField(); customerIdField.setPreferredSize(FIELD_SIZE);
        JTextField amountField = new JTextField(); amountField.setPreferredSize(FIELD_SIZE);

        restrictToNumeric(customerIdField);
        restrictToNumeric(amountField);

        int y = 0;
        addLabelAndField("Customer ID:", customerIdField, panel, gbc, labelFont, y++);
        addLabelAndField("Amount:", amountField, panel, gbc, labelFont, y++);

        gbc.gridx = 0; gbc.gridy = y; gbc.gridwidth = 2;
        JButton submitButton = new JButton("Add Payment");
        submitButton.setBackground(new Color(255, 223, 0));
        submitButton.setPreferredSize(BUTTON_SIZE);
        panel.add(submitButton, gbc);

        submitButton.addActionListener(e -> {
            Connection con = connect();
            if (con == null) return;
            String sql = "INSERT INTO payments (customer_id, amount) VALUES (?, ?)";
            try (PreparedStatement stmt = con.prepareStatement(sql)) {
                stmt.setInt(1, Integer.parseInt(customerIdField.getText()));
                stmt.setDouble(2, Double.parseDouble(amountField.getText()));
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(panel, "Payment added successfully!");
                customerIdField.setText(""); amountField.setText("");
            } catch (SQLException | NumberFormatException ex) {
                JOptionPane.showMessageDialog(panel, "Error: " + ex.getMessage());
            }
        });
        return panel;
    }

    private static JPanel createOrdersPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(245, 245, 255));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        Font labelFont = new Font("SansSerif", Font.PLAIN, 12);

        JTextField customerIdField = new JTextField(); customerIdField.setPreferredSize(FIELD_SIZE);
        JTextField tileIdField = new JTextField(); tileIdField.setPreferredSize(FIELD_SIZE);
        JTextField quantityField = new JTextField(); quantityField.setPreferredSize(FIELD_SIZE);

        restrictToNumeric(customerIdField);
        restrictToNumeric(tileIdField);
        restrictToNumeric(quantityField);

        int y = 0;
        addLabelAndField("Customer ID:", customerIdField, panel, gbc, labelFont, y++);
        addLabelAndField("Tile ID:", tileIdField, panel, gbc, labelFont, y++);
        addLabelAndField("Quantity:", quantityField, panel, gbc, labelFont, y++);

        gbc.gridx = 0; gbc.gridy = y; gbc.gridwidth = 2;
        JButton submitButton = new JButton("Add Order");
        submitButton.setBackground(new Color(255, 223, 0));
        submitButton.setPreferredSize(BUTTON_SIZE);
        panel.add(submitButton, gbc);

        submitButton.addActionListener(e -> {
            Connection con = connect();
            if (con == null) return;
            String sql = "INSERT INTO orders (customer_id, tile_id, quantity) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = con.prepareStatement(sql)) {
                stmt.setInt(1, Integer.parseInt(customerIdField.getText()));
                stmt.setInt(2, Integer.parseInt(tileIdField.getText()));
                stmt.setInt(3, Integer.parseInt(quantityField.getText()));
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(panel, "Order placed successfully!");
                customerIdField.setText(""); tileIdField.setText(""); quantityField.setText("");
            } catch (SQLException | NumberFormatException ex) {
                JOptionPane.showMessageDialog(panel, "Error: " + ex.getMessage());
            }
        });
        return panel;
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Tile Company Management");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 600);

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Tiles", createTilesPanel());
        tabbedPane.addTab("Customers", createCustomersPanel());
        tabbedPane.addTab("Suppliers", createSuppliersPanel());
        tabbedPane.addTab("Payments", createPaymentsPanel());
        tabbedPane.addTab("Orders", createOrdersPanel());

        frame.add(tabbedPane);
        frame.setVisible(true);
    }
}